appname='X-Publish'
appversion=1.30	# Must be numeric
